# Bingie

Kodi skin with Netflix layout.
